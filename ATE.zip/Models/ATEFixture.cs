﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ATE.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("ATEFixture")]
    public class ATEFixture
    {
        public int ATEFixtureID { get; set; }

        [StringLength(5)]
        public string KiemtraNgoaiquan { get; set; }

        [StringLength(5)]
        public string KiemtraKyhieu { get; set; }

        [StringLength(5)]
        public string KiemtraCaidat { get; set; }

        [StringLength(5)]
        public string KiemtraLamsach { get; set; }

        [StringLength(5)]
        public string KiemtraOcvit { get; set; }

        [StringLength(5)]
        public string KiemtraChantest { get; set; }

        [StringLength(5)]
        public string KiemtraBankhuon { get; set; }

        [StringLength(5)]
        public string KiemtraConnector { get; set; }

        [StringLength(5)]
        public string KiemtraOngkhi { get; set; }

        [StringLength(15)]
        public string FixtureName { get; set; }

        public int? Date { get; set; }

        [StringLength(15)]
        public string MaintainerID { get; set; }

        [StringLength(15)]
        public string Comfirmer { get; set; }

        [StringLength(50)]
        public string ModelName { get; set; }

        [StringLength(20)]
        public string RouteName { get; set; }

        [StringLength(15)]
        public string LineName { get; set; }

        [StringLength(15)]
        public string QA { get; set; }

        [StringLength(5)]
        public string ShiftName { get; set; }

        [StringLength(5)]
        public string KiemtraDonghoAplucKhi { get; set; }

        [StringLength(200)]
        public string KiemtraLucdanh { get; set; }

        [StringLength(200)]
        public string GhiChu { get; set; }

        [StringLength(200)]
        public string TieuchuanLucdanh { get; set; }

        //public virtual Accounttb Accounttb { get; set; }
    }
}
