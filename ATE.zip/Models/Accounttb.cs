﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ATE.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("Accounttb")]
    public partial class Accounttb
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Accounttb()
        {
            ATEFixtures = new HashSet<ATEFixture>();
            ATEMachines = new HashSet<ATEMachine>();
        }

        [Key]
        [StringLength(15)]
        public string MaintainerID { get; set; }

        [StringLength(100)]
        public string MaintainerPassword { get; set; }

        [StringLength(50)]
        public string Maintainer { get; set; }

        [StringLength(20)]
        public string Department { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        public int? Role { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ATEFixture> ATEFixtures { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ATEMachine> ATEMachines { get; set; }
    }
}
