﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ATE.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("ATEMachine")]
    public class ATEMachine
    {
        public int ATEMachineID { get; set; }

        public int? Date { get; set; }

        [StringLength(5)]
        public string Time { get; set; }

        [StringLength(50)]
        public string ModelName { get; set; }

        [StringLength(15)]
        public string StationName { get; set; }

        [StringLength(15)]
        public string ProgramName { get; set; }

        [StringLength(20)]
        public string ProgramVersion { get; set; }

        [StringLength(5)]
        public string CheckProgramVersion { get; set; }

        [StringLength(5)]
        public string RJ45RJ11 { get; set; }

        [StringLength(5)]
        public string PowerAdapter { get; set; }

        [StringLength(5)]
        public string USBCable { get; set; }

        [StringLength(5)]
        public string RS232Cable { get; set; }

        [StringLength(5)]
        public string HighSpeedConnector { get; set; }

        [StringLength(5)]
        public string GroundWire { get; set; }

        [StringLength(20)]
        public string AntivirusVersion { get; set; }

        [StringLength(5)]
        public string SmartCard { get; set; }

        [StringLength(5)]
        public string Simulator { get; set; }

        [StringLength(50)]
        public string Maintainer { get; set; }

        [StringLength(15)]
        public string MaintainerID { get; set; }

        [StringLength(20)]
        public string RouteName { get; set; }

        [StringLength(15)]
        public string LineName { get; set; }

        [StringLength(5)]
        public string DVBCICard { get; set; }

        [StringLength(5)]
        public string AVCable { get; set; }

        [StringLength(15)]
        public string QA { get; set; }

        //public virtual Accounttb Accounttb { get; set; }
    }
}
