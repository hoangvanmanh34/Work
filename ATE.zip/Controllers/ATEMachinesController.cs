﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ATE.Models;

namespace ATE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ATEMachinesController : ControllerBase
    {
        private readonly ATEContext _context;

        public ATEMachinesController(ATEContext context)
        {
            _context = context;
        }

        // GET: api/ATEMachines
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ATEMachine>>> GetATEMachine()
        {
            return await _context.ATEMachine.ToListAsync();
        }

        // GET: api/ATEMachines/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ATEMachine>> GetATEMachine(int id)
        {
            var aTEMachine = await _context.ATEMachine.FindAsync(id);

            if (aTEMachine == null)
            {
                return NotFound();
            }

            return aTEMachine;
        }

        //// GET: api/ATEMachines/
        ////[Route ("api/ATEMachines/")]
        //[HttpGet("{stationName}/{date}")]
        //public async Task<ActionResult<IEnumerable<ATEMachine>>> GetATEMachineInfo(string stationName, int date)
        //{
        //    string icmd = "exec ATEMachinebyMachineName @stationName='" + stationName + "', @date=" + date;
        //    var aTEMachine = await _context.ATEMachine.FromSqlRaw(icmd).ToListAsync();
        //    if (aTEMachine == null || aTEMachine.Count == 0)
        //    {
        //        return NotFound();
        //    }

        //    return aTEMachine;
        //}
        // GET: api/ATEFixtures/info/5
        [HttpGet("{machineName}/{date}")]
        public async Task<IActionResult> GetATEMachineInfo(string machineName, int date)
        {
            string icmd = "exec ATEMachinebyMachineName @stationName='" + machineName + "', @date=" + date;
            var aTEMachine = await _context.ATEMachine.FromSqlRaw(icmd).ToListAsync();

            if (aTEMachine == null || aTEMachine.Count == 0)
            {
                return NotFound();
            }
            List<object> dresult = new List<object> { };

            foreach (var ate in aTEMachine)
            {
                //string jresult = JsonConvert.SerializeObject(ate, Formatting.Indented);
                //dresult.Insert(dresult.Count, "{'MachineName':'" + ate.StationName + "','Date':" + ate.Date + "}");
                Dictionary<string, object> points = new Dictionary<string, object> { };
                points.Add("MachineName", ate.StationName);
                points.Add("Date", ate.Date);
                dresult.Insert(dresult.Count, points);
            }

            return new JsonResult(dresult);
        }

        //Server=(localdb)\\mssqllocaldb;Database=ATEFixtureContext-71f33bc6-63cc-45b9-94c6-7aeb8a3d7f14;Trusted_Connection=True;MultipleActiveResultSets=true
         
        // PUT: api/ATEMachines/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutATEMachine(int id, ATEMachine aTEMachine)
        {
            if (id != aTEMachine.ATEMachineID)
            {
                return BadRequest();
            }

            _context.Entry(aTEMachine).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ATEMachineExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ATEMachines
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<ATEMachine>> PostATEMachine(ATEMachine aTEMachine)
        {
            _context.ATEMachine.Add(aTEMachine);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetATEMachine", new { id = aTEMachine.ATEMachineID }, aTEMachine);
        }

        // DELETE: api/ATEMachines/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<ATEMachine>> DeleteATEMachine(int id)
        {
            var aTEMachine = await _context.ATEMachine.FindAsync(id);
            if (aTEMachine == null)
            {
                return NotFound();
            }

            _context.ATEMachine.Remove(aTEMachine);
            await _context.SaveChangesAsync();

            return aTEMachine;
        }

        private bool ATEMachineExists(int id)
        {
            return _context.ATEMachine.Any(e => e.ATEMachineID == id);
        }
    }
}
