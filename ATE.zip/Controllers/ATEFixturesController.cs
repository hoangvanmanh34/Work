﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ATE.Models;
using Newtonsoft.Json;

namespace ATE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ATEFixturesController : ControllerBase
    {
        private readonly ATEContext _context;

        public ATEFixturesController(ATEContext context)
        {
            _context = context;
        }

        // GET: api/ATEFixtures
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ATEFixture>>> GetATEFixture()
        {
            return await _context.ATEFixture.ToListAsync();
        }

        // GET: api/ATEFixtures/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ATEFixture>> GetATEFixture(int id)
        {
            var aTEFixture = await _context.ATEFixture.FindAsync(id);

            if (aTEFixture == null)
            {
                return NotFound();
            }

            return aTEFixture;
        }

        //// GET: api/ATEFixtures/info/5
        //[HttpGet("{fixtureName}/{date}")]
        ////public async Task<ActionResult<IEnumerable<ATEFixture>>> GetATEFixtureInfo(string fixtureName, int date)
        //public async Task<ActionResult<IEnumerable<ATEFixture>>> GetATEFixtureInfoList(string fixtureName, int date)
        //{
        //    string icmd = "exec ATEFixturebyFixtureName @fixtureName='" + fixtureName + "', @date=" + date;
        //    var aTEFixture = await _context.ATEFixture.FromSqlRaw(icmd).ToListAsync();

        //    if (aTEFixture == null || aTEFixture.Count == 0)
        //    {
        //        return NotFound();
        //    }
        //    return aTEFixture;
        //}

        // GET: api/ATEFixtures/info/5
        [HttpGet("{fixtureName}/{date}")]
        public async Task<IActionResult> GetATEFixtureInfo(string fixtureName, int date)
        {
            string icmd = "exec ATEFixturebyFixtureName @fixtureName='" + fixtureName + "', @date=" + date;
            var aTEFixture = await _context.ATEFixture.FromSqlRaw(icmd).ToListAsync();

            if (aTEFixture == null || aTEFixture.Count == 0)
            {
                return NotFound();
            }
            List<object> dresult = new List<object> { };
            
            foreach (var ate in aTEFixture)
            {
                //string jresult = JsonConvert.SerializeObject(ate, Formatting.Indented);
                Dictionary<string, object> points = new Dictionary<string, object> { };
                points.Add("FixtureName", ate.FixtureName);
                points.Add("Date", ate.Date);
                points.Add("ShiftName", ate.ShiftName);

                //dresult.Insert(dresult.Count, new JsonResult("{'FixtureName':'" + ate.FixtureName+ "','Date':" + ate.Date + "','ShiftName':" + ate.ShiftName + "}"));
                dresult.Insert(dresult.Count, points);

            }

            return new JsonResult(dresult);
        }
        //[{"ateFixtureID":88,"kiemtraNgoaiquan":"V","kiemtraKyhieu":"V","kiemtraCaidat":"X","kiemtraLamsach":"V","kiemtraOcvit":"V","kiemtraChantest":"","kiemtraBankhuon":"V","kiemtraConnector":"","kiemtraOngkhi":"","fixtureName":"LT4L292RC004","date":20180614,"maintainerID":"V0916166","comfirmer":"","modelName":"U46L292.05","routeName":"RC        ","lineName":null,"qa":null,"shiftName":"Night","kiemtraDonghoAplucKhi":null,"kiemtraLucdanh":null,"ghiChu":null,"tieuchuanLucdanh":null}]

        // PUT: api/ATEFixtures/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutATEFixture(int id, ATEFixture aTEFixture)
        {
            if (id != aTEFixture.ATEFixtureID)
            {
                return BadRequest();
            }

            _context.Entry(aTEFixture).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ATEFixtureExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ATEFixtures
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<ATEFixture>> PostATEFixture(ATEFixture aTEFixture)
        {
            _context.ATEFixture.Add(aTEFixture);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetATEFixture", new { id = aTEFixture.ATEFixtureID }, aTEFixture);
        }

        // DELETE: api/ATEFixtures/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<ATEFixture>> DeleteATEFixture(int id)
        {
            var aTEFixture = await _context.ATEFixture.FindAsync(id);
            if (aTEFixture == null)
            {
                return NotFound();
            }

            _context.ATEFixture.Remove(aTEFixture);
            await _context.SaveChangesAsync();

            return aTEFixture;
        }

        private bool ATEFixtureExists(int id)
        {
            return _context.ATEFixture.Any(e => e.ATEFixtureID == id);
        }
    }
}
