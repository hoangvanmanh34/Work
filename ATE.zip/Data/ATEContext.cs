﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ATE.Models;

namespace ATE.Models
{
    public class ATEContext : DbContext
    {
        public ATEContext (DbContextOptions<ATEContext> options)
            : base(options)
        {
        }
        //"ATEContext": "Data Source=TE_SERVER-PC;Initial Catalog=EMaintenance;Persist Security Info=True;User ID=sa;Password=Admin@123",
        public DbSet<ATE.Models.ATEMachine> ATEMachine { get; set; }
        public DbSet<ATE.Models.ATEFixture> ATEFixture { get; set; }
    }
}
